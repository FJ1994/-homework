<template>
  <div id="app">
    <List></List>
  </div>
</template>

<script>
import List from "./components/List.vue";

export default {
  name: "app",
  components: {
    List
  }
};
</script>

<style>
</style>
